const AllFigureText = () => {
    return (
        <span className=" allFigr w3-right  w3-text-red " > * All figures are in Lacs (INR)  </span>
    )
}

export default AllFigureText;