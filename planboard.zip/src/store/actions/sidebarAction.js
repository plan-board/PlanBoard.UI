import { SidebarStatus } from "../constant/types";

export const changeSidebarStatus = () => {
  return {
    type: SidebarStatus,
  };
};
